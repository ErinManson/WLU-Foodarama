package cp213;

import java.awt.Font;
import java.util.HashMap; // import the HashMap class


import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.math.BigDecimal;

/**
 * Stores a HashMap of MenuItem objects and the quantity of each MenuItem
 * ordered. Each MenuItem may appear only once in the HashMap.
 *
 * @author Erin Manson
 * @author Abdul-Rahman Mawlood-Yunis
 * @author David Brown
 * @version 2022-11-20
 */
public class Order implements Printable {

    /**
     * The current tax rate on menu items.
     */
    public static final BigDecimal TAX_RATE = new BigDecimal(0.13);


    HashMap<MenuItem, Integer> ordermap = new HashMap<MenuItem, Integer>();


    /**
     * Increments the quantity of a particular MenuItem in an Order with a new
     * quantity. If the MenuItem is not in the order, it is added.
     *
     * @param item     The MenuItem to purchase - the HashMap key.
     * @param quantity The number of the MenuItem to purchase - the HashMap value.
     */
    public void add(final MenuItem item, final int quantity) {

    	if (ordermap.containsKey(item)) { //if the key is already in the hash map
    		int newval = ordermap.get(item) + quantity; //the new value will be old value plus quantity
    		ordermap.remove(item); //remove old 
    		ordermap.put(item, newval); //add new 
    	} else {
    		ordermap.put(item, quantity);//else add new element 
    	}
    }

    /**
     * Calculates the total value of all MenuItems and their quantities in the
     * HashMap.
     *
     * @return the total price for the MenuItems ordered.
     */
    public BigDecimal getSubTotal() {
    BigDecimal total = new BigDecimal(0);
    
    for (var element : ordermap.entrySet()) {
    	total = total.add((element.getKey().getPrice()).multiply(BigDecimal.valueOf(element.getValue())));
    }
	return total;
    }

    /**
     * Calculates and returns the total taxes to apply to the subtotal of all
     * MenuItems in the order. Tax rate is TAX_RATE.
     *
     * @return total taxes on all MenuItems
     */
    public BigDecimal getTaxes() {
    BigDecimal taxes = new BigDecimal(0);
    if ( this.getSubTotal() != new BigDecimal(0)) {
    	taxes = this.getSubTotal().multiply(TAX_RATE);
    	
    }
	
	return taxes;
    }

    /**
     * Calculates and returns the total price of all MenuItems order, including tax.
     *
     * @return total price
     */
    public BigDecimal getTotal() {

	BigDecimal total = this.getTaxes().add(this.getSubTotal());

	return total;
    }

    /*
     * Implements the Printable interface print method. Prints lines to a Graphics2D
     * object using the drawString method. Prints the current contents of the Order.
     */
    @Override
    public int print(final Graphics graphics, final PageFormat pageFormat, final int pageIndex)
	    throws PrinterException {
	int result = PAGE_EXISTS;

	if (pageIndex == 0) {
	    final Graphics2D g2d = (Graphics2D) graphics;
	    g2d.setFont(new Font("MONOSPACED", Font.PLAIN, 12));
	    g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
	    // Now we perform our rendering
	    final String[] lines = this.toString().split("\n");
	    int y = 100;
	    final int inc = 12;

	    for (final String line : lines) {
		g2d.drawString(line, 100, y);
		y += inc;
	    }
	    
	} else {
	    result = NO_SUCH_PAGE;
	}
	return result;
    }

    /**
     * Returns a String version of a receipt for all the MenuItems in the order.
     */
    @Override
    public String toString() {
    String receipt = "";
	for (var element: ordermap.entrySet()) {
	    receipt += String.format("%-13s %2d", element.getKey().getName(), element.getValue());
	    receipt += " @ " + String.format("$%5.2f", element.getKey().getPrice());
	    receipt += " = " + String.format("$%6.2f", BigDecimal.valueOf(element.getValue()).multiply(element.getKey().getPrice()));
	    receipt += "\n";
	}
	receipt += "\n" + String.format("%-27s $%6.2f", "Subtotal:", this.getSubTotal()) + "\n";
	receipt += String.format("%-27s $%6.2f", "Taxes:", this.getTaxes()) + "\n";
	receipt += String.format("%-27s $%6.2f", "Total:", this.getTotal()) + "\n";

	return receipt;
    }

    /**
     * Replaces the quantity of a particular MenuItem in an Order with a new
     * quantity. If the MenuItem is not in the order, it is added. If quantity is 0
     * or negative, the MenuItem is removed from the Order.
     *
     * @param item     The MenuItem to update
     * @param quantity The quantity to apply to item
     */
    public void update(final MenuItem item, final int quantity) {

    	if (quantity <= 0) { //if less than or equal to zero remove key
    		ordermap.remove(item);
    	} else { // quantity is positive add/update
    		if (ordermap.containsKey(item)) { //if already inside remove old first 
    			ordermap.remove(item);
    		} 
    		ordermap.put(item,  quantity); //now key is not in order map so we add new key value pair 
    	}
    
    }
}