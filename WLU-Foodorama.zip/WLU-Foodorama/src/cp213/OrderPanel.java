package cp213;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.PrinterJob;
import java.awt.print.PrinterException;


/**
 * The GUI for the Order class.
 *
 * @author Erin Manson
 * @author Abdul-Rahman Mawlood-Yunis
 * @author David Brown
 * @version 2022-11-20
 */
@SuppressWarnings("serial")
public class OrderPanel extends JPanel {
	
    // Attributes
    private Menu menu = null; // Menu attached to panel.
    private final Order order = new Order(); // Order to be printed by panel.
    // GUI Widgets
    private final JButton printButton = new JButton("Print");
    private final JLabel subtotalLabel = new JLabel(String.format("$%6.2f", 0.00));
    private final JLabel taxLabel = new JLabel(String.format("$%6.2f", 0.00));
    private final JLabel totalLabel = new JLabel(String.format("$%6.2f", 0.00));

    private JLabel nameLabels[] = null;
    private JLabel priceLabels[] = null;
    // TextFields for menu item quantities.
    private JTextField quantityFields[] = null;

    /**
     * Displays the menu in a GUI.
     *
     * @param menu The menu to display.
     */
    public OrderPanel(final Menu menu) {
	this.menu = menu;
	this.nameLabels = new JLabel[this.menu.size()];
	this.priceLabels = new JLabel[this.menu.size()];
	this.quantityFields = new JTextField[this.menu.size()];
	this.layoutView();
	this.registerListeners();
    }

    /**
     * Implements an ActionListener for the 'Print' button. Prints the current
     * contents of the Order to a system printer or PDF.
     */
    private class PrintListener implements ActionListener {

	@Override
	public void actionPerformed(final ActionEvent e) {
		
		PrinterJob job = PrinterJob.getPrinterJob();
		job.setJobName("receipt");
		PageFormat format = job.defaultPage();
		Paper paperholder = new Paper();
		format.setPaper(paperholder);
		
		job.setPrintable(order, format);
		if (job.printDialog()) {
			try {
				job.print();
			} catch (PrinterException e1) {
				System.out.println("PRINTER ERROR");
			}
		}
		
		
		

	}
    }

    /**
     * Implements a FocusListener on a quantityField. Requires appropriate
     * FocusListener methods.
     */
    private class QuantityListener implements FocusListener {
    	// Automatically highlight the entire contents of the numeric field.
    	@Override
    	public void focusGained(final FocusEvent evt) {
    		final JTextField source = (JTextField) evt.getSource();
    		source.selectAll();
    	}
    	@Override
    	public void focusLost(final FocusEvent evt) {
    		final JTextField source = (JTextField) evt.getSource();
    		int ind = 0;
    		for (JTextField textbox : OrderPanel.this.quantityFields) {
    			if (textbox == source) {
    				break;
    			} else {
    				ind += 1;
    			}
    		}
    		String newquantity = source.getText();
    		int newval = 0;
    		if (newquantity.isEmpty()) {
    			newval = 0;
    		} else {
    			try {
    				newval = Integer.valueOf(newquantity);
    			} catch (NumberFormatException e) {
    				newval = 0;
    				source.setText("");
    			}
    		}
    		order.update(menu.getItem(ind), newval);
    		OrderPanel.this.subtotalLabel.setText(String.format("$%6.2f", order.getSubTotal()));
    		OrderPanel.this.totalLabel.setText(String.format("$%6.2f", order.getTotal()));
    		OrderPanel.this.taxLabel.setText(String.format("$%6.2f", order.getTaxes()));

    	}
    }

    /**
     * Layout the panel.
     */
    private void layoutView() {
    	
    	this.setLayout(new BorderLayout());
    	OrderPanel.this.setBackground(new Color(169, 132, 207));
    	this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    	this.setLayout(new GridLayout(0, 3));

    	JLabel titleLabel = new JLabel("~~~~~ WLU ");
    	titleLabel.setHorizontalAlignment(SwingConstants.RIGHT);
    	titleLabel.setFont(new Font("Baskerville", Font.BOLD | Font.ITALIC, 21));
    	JLabel titleLabel2 = new JLabel(" Foodorama");
    	titleLabel2.setHorizontalAlignment(SwingConstants.CENTER);
    	titleLabel2.setFont(new Font("Baskerville", Font.BOLD | Font.ITALIC, 22));
    	JLabel titleLabel3 = new JLabel("~~~~~~~~");
    	titleLabel3.setHorizontalAlignment(SwingConstants.LEFT);
    	titleLabel3.setFont(new Font("Baskerville", Font.BOLD | Font.ITALIC, 21));
    	

    	this.add(titleLabel);
    	this.add(titleLabel2);
    	this.add(titleLabel3);
    	
    	this.add(new JLabel(""));
    	this.add(new JLabel(""));
    	this.add(new JLabel(""));

    	JLabel toplabel = new JLabel("Item");
    	JLabel toplabel2 = new JLabel("Price");
    	JLabel toplabel3 = new JLabel("Quantity");
    	toplabel.setFont(new Font("Baskerville", Font.BOLD, 16));
        toplabel.setHorizontalAlignment(SwingConstants.CENTER);
    	toplabel2.setFont(new Font("Baskerville", Font.BOLD, 16));
        toplabel2.setHorizontalAlignment(SwingConstants.CENTER);
    	toplabel3.setFont(new Font("Baskerville", Font.BOLD, 16));
        toplabel3.setHorizontalAlignment(SwingConstants.CENTER);
       
  
    	this.add(toplabel);
    	this.add(toplabel2);
    	this.add(toplabel3);
    	
    	//this.add(new JLabel(""));
    	//this.add(new JLabel(""));
    	//this.add(new JLabel(""));
    	
    	int i = 0;
    	for (MenuItem item: this.menu.items) {
    		this.nameLabels[i] = new JLabel(item.getName().substring(0, 1).toUpperCase() + item.getName().substring(1, item.getName().length()));
    		this.nameLabels[i].setFont(new Font("Baskerville", Font.BOLD, 14));
    		this.add(this.nameLabels[i]);

    		this.priceLabels[i] = new JLabel("$" + item.getPrice().toString() + "     ");
    		this.add(this.priceLabels[i]);
    		this.priceLabels[i].setFont(new Font("Baskerville", Font.BOLD, 14));
    		this.priceLabels[i].setHorizontalAlignment(SwingConstants.RIGHT);
    		this.quantityFields[i] = new JTextField();
    		this.quantityFields[i].setBackground(new Color(216, 186, 247));
    		this.add(this.quantityFields[i]);
    		i += 1;

    	}
    	this.add(new JLabel(""));
    	this.add(new JLabel(""));
    	this.add(new JLabel(""));

    	JLabel totallabel = new JLabel("Subtotal:");
    	totallabel.setFont(new Font("Baskerville", Font.BOLD, 18));

    	this.add(totallabel);

    	this.add(new JLabel(""));
    	this.add(this.subtotalLabel);
        this.subtotalLabel.setFont(new Font("Baskerville", Font.BOLD, 14));
        this.subtotalLabel.setHorizontalAlignment(SwingConstants.RIGHT);


    	JLabel totallabel2 = new JLabel("Tax:");
    	totallabel2.setFont(new Font("Baskerville", Font.BOLD, 18));
    	this.add(totallabel2);

    	this.add(new JLabel(""));
    	this.add(this.taxLabel);
        this.taxLabel.setFont(new Font("Baskerville", Font.BOLD, 14));
        this.taxLabel.setHorizontalAlignment(SwingConstants.RIGHT);


    	JLabel totallabel3 = new JLabel("Total:");
    	totallabel3.setFont(new Font("Baskerville", Font.BOLD, 18));
    	this.add(totallabel3);

    	this.add(new JLabel(""));
    	this.add(this.totalLabel);
        this.totalLabel.setFont(new Font("Baskerville", Font.BOLD, 14));
        this.totalLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        
        
    	this.add(new JLabel(""));
    	this.add(new JLabel(""));

        this.add(new JLabel("---------------"));
        this.add(new JLabel(""));
        this.add(printButton);
        
        this.printButton.setBackground(new Color(230, 115, 216));
        this.printButton.setOpaque(true);
        this.printButton.setBorderPainted(false);
        this.printButton.setFont(new Font("Chalkboard", Font.ITALIC, 16));
        this.add(new JLabel(""));



    	


    }

    /**
     * Register the widget listeners.
     */
    private void registerListeners() {
	// Register the PrinterListener with the print button.
	this.printButton.addActionListener(new PrintListener());
	
	for (JTextField quant: this.quantityFields) {
		quant.addFocusListener(new QuantityListener());
		
	}
    }

}