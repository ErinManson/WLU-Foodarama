package cp213;

import java.util.Scanner;

/**
 * Wraps around an Order object to ask for MenuItems and quantities.
 *
 * @author Erin Manson
 * @author Abdul-Rahman Mawlood-Yunis
 * @author David Brown
 * @version 2022-11-20
 */
public class Cashier {

    // Attributes
    private Menu menu = null;

    /**
     * Constructor.
     *
     * @param menu A Menu.
     */
    public Cashier(Menu menu) {
	this.menu = menu;
    }

    /**
     * Prints the menu.
     */
    private void printCommands() {
	System.out.println("\nMenu:");
	System.out.println(menu.toString());
	System.out.println("Press 0 when done.");
	System.out.println("Press any other key to see the menu again.\n");
    }

    /**
     * Asks for commands and quantities. Prints a receipt when all orders have been
     * placed.
     *
     * @return the completed Order.
     */
    public Order takeOrder() {
    
    	System.out.println("Welcome to WLU Foodorama!");

    	final Scanner keyboard = new Scanner(System.in);
    	Order order = getOrder(keyboard);
    	keyboard.close();

	return order;
    }

	public Order getOrder(Scanner keyboard) {
		Order order = new Order();
		this.printCommands();
		boolean cancel = false;
		
		while (! cancel) { //while the user has not cancelled 
			System.out.print("Command: "); //show command
			
			if (keyboard.hasNextInt()) { //if int command was enterred 
		    	int val = Integer.valueOf(keyboard.nextLine());
		    	
		    	if (val > 0 && val <= this.menu.size()) { //if int command was valid > 0 and <= size of menu
		    		System.out.print("How many do you want? "); //ask how many 
		    		
		    		if (keyboard.hasNextInt()) { //if int quantity was enterred 
		    			int quant = Integer.valueOf(keyboard.nextLine());
		    			if (quant > 0){ //only quantities greater than 0 valid 
			    			order.add(menu.getItem(val - 1), quant); //add item to order at index -1 to val
			    			//recall adding to an order increments quantity if already exists and adds otherwise 
		    			} else {
		    				System.out.print("Not a valid number");
		    			}
		    			
		    		} else {
		    			keyboard.nextLine();
		    			System.out.println("Not a valid number");
		    		}
		    	} else {
		    		if (val == 0) {
		    			cancel = true;
		    		    System.out.println("-".repeat(40));
		    		    System.out.println("Receipt");

		    		} else {
		    			this.printCommands();
		    		}
		    	}
		    } else {
		    	keyboard.nextLine();
		    	System.out.println("Not a valid number");
		    	this.printCommands();
		    }
		}
		
	return order;
	}
}